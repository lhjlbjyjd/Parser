#ifndef CURLPARSE_H_INCLUDED
#define CURLPARSE_H_INCLUDED

#include <fstream>
#include <iostream>
#include <cstring>
#include <string>
#include <curl/curl.h>

using namespace std;

class curlParse{

    string url;

public:
    curlParse(string url)
    {
        this -> url = url;
    }

    static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
    {
        ((string*)userp)->append((char*)contents, size * nmemb);
        return size * nmemb;
    }


    string getStringFromDoc()
    {


        curl_global_init(CURL_GLOBAL_ALL);

        CURL *curl;
        CURLcode res;
        string readBuffer;


        curl = curl_easy_init();
        if(curl) {

            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
            res = curl_easy_perform(curl);
            curl_easy_cleanup(curl);

        }
        return readBuffer;



    }





};

#endif // CURLPARSE_H_INCLUDED
