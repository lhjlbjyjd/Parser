#ifndef COMFYPARSE_H_INCLUDED
#define COMFYPARSE_H_INCLUDED

#include <iostream>
#include <cstring>
#include <vector>
#include <fstream>

#include "stringParse.h"
#include "curlParse.h"

using namespace std;

class comfyParse{

public:
    string html, url;

    comfyParse(string url){
        this -> url = url;
        sPageParse(url);
    }

// begin page parse - функция для получения ссылок с начальной страницы
    void bPageParse(){

        curlParse *o = new curlParse(url);
        html = o ->getStringFromDoc();
        delete o;

        if(html.length()) cout<<"Start page load success "<<url<<"\n";

        stringParse *k = new stringParse(&html);
        vector <long long int> t = k -> doKmp("<a");


        int flStr = 0;


        for(int i=0; i<t.size(); i++){

            string tValue = "menu-categories-list";
            string tagStr = k -> getTagAll(t[i],"a");
            string fValue = k -> attrSearch("class",&tagStr);

            long long int flag = -1;
            flag = k -> doKmpAttr(&tValue,&fValue);

            if(flag!=-1)
            {

                string href = k -> attrSearch("href",&tagStr);
                hrefVld(href);

                sPageParse(href);
            }

        }


        delete k;


    }

// second page parse - функция для получения количества моделей
    void sPageParse(string &href){
        curlParse *o = new curlParse(href);
        string page;
        page =  o ->getStringFromDoc();
        delete o;

        if(page.length()) cout<<"Products page load success "<<href<<"\n";
// получаем строчку, в которой содержится количество моделей
// и обрабатываем число
        vector <string> mdl;

        stringParse *strPrs = new stringParse(&page);
        strPrs -> getSpcBody("span","id=productsCount", &mdl);
        delete strPrs;

        tidyUp(&mdl);

// возможная ошибка
        if(!mdl.size()) return;

        string s = mdl[0];

        long long int mdlNum = 0;

        for(int i=0; i<s.length(); i++)
        {
            if(s[i]==' ') break;
            mdlNum *=10;

            mdlNum += (long long int) (s[i]-'0');

        }

// теперь будем скакать по страницам
        long long int cnt = 0;

        string hrefObj = href + "?p=";

        for(long long int i=1; cnt<mdlNum; i++)
        {
            string k;
            long long int u = i;
            while(u>0){
                int j = u % 10;
                u/=10;
                k+= (char) (j+'0');
            }
            string kRev = hrefObj;
            for(int j = k.length()-1; j>-1; j--) kRev += k[j];

            objPageParse(kRev, cnt);
            cnt++;
        }


    }

// object page parse - функция для получения данных со страницы товара

    void objPageParse(string &href, long long int &cnt)
    {
        curlParse *o = new curlParse(href);
        string page;
        page =  o ->getStringFromDoc();
        delete o;

        if(page.length()) cout<<"Products page load success "<<href<<"\n";



        stringParse *k = new stringParse(&page);
        vector <long long int> t = k -> doKmp("<a");


        //ДОБАВЛЕНО КРИВОРУКИМ ДОЛБОЁБОМ
        string previousHref = "";
        string otziviEnding = "-otzyvy.html";
        string videoEnding = "-video.html";


        for(int i=0; i<t.size(); i++){

            string tValue = "product-item";
            string tagStr = k -> getTagAll(t[i],"a");
            string fValue = k -> attrSearch("class",&tagStr);

            long long int flag = -1;
            flag = k -> doKmpAttr(&tValue,&fValue);

            if(flag!=-1)
            {
                cnt++;
                string hrefFinal = k -> attrSearch("href",&tagStr);

                if(hrefFinal.compare(previousHref) != 0 && hrefFinal.compare("") != 0 && hrefFinal != "https://comfy.ua/catalog/product_compare"
                        && !hasEnding (hrefFinal, otziviEnding) && !hasEnding (hrefFinal, videoEnding)) {

                    previousHref = hrefFinal;

                    string title = k->attrSearch("title", &tagStr);
                    hrefVld(hrefFinal);

                    vector<string> ftr;
                    finalPageParse(hrefFinal, &ftr);

                    ofstream out;

                    string path = "../results/" + title + ".txt";
                    char *c = &(path[0]);
                    out.open(c);

                    for (int i = 0; i < ftr.size(); i++)
                        out << ftr[i] << "\n";

                    out.close();
                }

            }

        }

        delete k;

    }




// final page parse - функция для получения данных со страницы товара

    void finalPageParse(string &href,vector <string> *ftr){
// feature vector - содержит заголовок и особенности товара

        curlParse *o = new curlParse(href);
        string page;
        page = o ->getStringFromDoc();
        delete o;

        if(page.length()) cout<<"Final page load success "<<href<<"\n";

        stringParse *strPrs = new stringParse(&page);

        vector <string> prs;
        strPrs -> getSpcBody("dl","class=features-item__list", &prs);
        delete strPrs;

        for(int i=0; i<prs.size(); i++){
            stringParse *strPrs = new stringParse(&(prs[i]));

            strPrs -> getSpcBody("dt","class=title",ftr);

            strPrs -> getSpcBody("dd","class=value",ftr);

            delete strPrs;
        }
        tidyUp(ftr);

        //ДОБАВЛЕНО КРИВОРУКИМ ДОЛБОЁБОМ
        serialiseContent(ftr);
    }

    void serialiseContent(vector <string> *ftr){

        Serializer *serializer = new Serializer();

        bool pair = true;

        for(unsigned long i=0; i<ftr -> size(); i++)
        {
            if(pair) {
                string s;
                s = serializer->serialize((*ftr)[i]);
                (*ftr)[i] = s;
            }else{
                string s;
                s = serializer->serializeValues((*ftr)[i-1], (*ftr)[i]);
                (*ftr)[i] = s;
            }
            pair = !pair;
        }

        delete serializer;

    }

    void tidyUp(vector <string> *ftr){

        for(int i=0; i<ftr -> size(); i++)
        {
            string s;

            unsigned long d = (*ftr)[i].length();
            for(unsigned long j = 0; j<d; j++)
            {
                char c = (*ftr)[i][j];
                if(c=='<') break;
                if(c=='\n' || c=='\r') continue;
                if(c!=' ') s+=c;
                else if(j!=0 && (*ftr)[i][j-1]!=' ' && (*ftr)[i][j-1]!='\n') s+=c;

            }
            (*ftr)[i] = s;
        }

    }

// href validation - если ссылка не абсолютна, делает её таковой.
    void hrefVld(string &href){
        if(href[0]=='/') href = url+href;
    }

    //Оканчивается ли строка чем то

    bool hasEnding (std::string const &fullString, std::string const &ending) {
        if (fullString.length() >= ending.length()) {
            return (0 == fullString.compare (fullString.length() - ending.length(), ending.length(), ending));
        } else {
            return false;
        }
    }

};


#endif // COMFYPARSE_H_INCLUDED
