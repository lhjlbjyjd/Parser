#ifndef STRINGPARSE_H_INCLUDED
#define STRINGPARSE_H_INCLUDED

#include <iostream>
#include <cstring>
#include <vector>
#include "Serializer.h"

using namespace std;

class stringParse{

public:
    string *html;
    string *cStr;

    stringParse(string *html){
        this->html = html;
        cStr = html;
    }

    void setCurStr(string *cStr)
    {
        this -> cStr = cStr;
    }

    // ищет первую строку во основной и возвращает вектор long long int, в котором записаны
    // позиции вхождения первой строки во вторую, кр4 алгоритм КМП
    vector <long long int> doKmp(string a)
    {
// сливаем две строки для алгоритма кмп
        string s = a + "@" + *html;

        long long int *m, l = s.length(), p = a.length();
        vector <long long int> srtPositions;
        m = new long long int [l];
        for(long long int i=0; i<=p; i++) m[i]=0;

        for(long long int i = p+1; i < l ; i++){
            long long int j = m[i-1];
            while(j>0 && s[i]!=s[j]) j  = m[j];
            if(s[i]==s[j]) j++;
            m[i]=j;
            if(j==p) srtPositions.push_back(i-2*p);


        }
        delete m;
        return srtPositions;
    }

    // возвращает индекс вхождения аттрибута(одного !), при этом останавливается, встречая
    // конец тэга '>'
    long long int doKmpAttr(string *a, string *b){
        string s = *a + "@" + *b;

        long long int *m, l = s.length(), p = a -> length();
        long long int srtPosition = -1;
        m = new long long int [l];
        for(long long int i=0; i<p+1; i++) m[i]=0;

        for(long long int i = p+1; i < l ; i++){
            if(s[i]=='>') break;
            long long int j = m[i-1];
            while(j>0 && s[i]!=s[j]) j  = m[j];
            if(s[i]==s[j]) j++;
            m[i]=j;
            if(j==p){
                srtPosition = i-2*p;
                break;
            }
        }
        delete m;
        return srtPosition;



    }
    // ищет  конец тага, затем копирует  само тело тага в строку и возвращает его
    // параметр 1 - позиция вхождения начала тага в основную строку
    // параметр 2 - сам таг без кавычек(!)
    string getTagBody(long long int tagPos, string tag)
    {
        string tagStr;
        string endTag = "</" + tag;
        string srtTag = "<" + tag;
        long long int b = html -> length(),
                c = endTag.length(),
                d = srtTag.length(),
                tagEndPos = b,
                depth = 0;
        ;
        int fl, ag;
        for(long long int i = tagPos;; i++){
            int fl = 1;
            for(int j = 0; j<c; j++)
                if((*html)[i+j]!=endTag[j])
                {
                    fl = 0;
                    break;
                }
            if(fl) depth--;
            if(fl && !depth)
            {
                tagEndPos = i;

                break;
            }
            else
            {
                int ag = 1;
                for(int j = 0; j<d; j++)
                    if((*html)[i+j]!=srtTag[j])
                    {
                        ag = 0;
                        break;
                    }
                if(ag) depth++;

            }
        }
        depth = 0;
        long long int srtTagEnd = tagPos;
        for(;;srtTagEnd++)
        {
            char sym = (*html)[srtTagEnd];
            if(sym=='<') depth++;
            else if(sym=='>') depth--;

            if(!depth) break;
        }

        for(long long int i = srtTagEnd+1; i<tagEndPos; i++) tagStr+=(*html)[i];
        return tagStr;
    }

    string getTagAll(long long int tagPos, string tag)
    {
        string tagStr;
        char *c = &((*html)[tagPos]);

        long long int depth = 0;
        long long int i;

        for(i=0;;i++){

            if(c[i]=='<') depth++;
            else if(c[i]=='>') depth--;

            tagStr += c[i];

            if(!depth) break;
        }



        return tagStr;
    }
    // ищет аттрибут
    string attrSearch(string attr, string *tagStr){
        long long int srtPos = doKmpAttr(&attr,tagStr);

        if(srtPos==-1) return "";

        string attrVal;
        int k = srtPos + attr.length()+2;
        for(long long  i = k;;i++)
        {
            if((*tagStr)[i]=='\"')  break;
            attrVal+=(*tagStr)[i];
        }

        return attrVal;
    }
    // ищет первый подходящий по требованиям таг и возвращает его тело
    // поиск происходит в строке, на которую указывает cStr (string pointer)
    void getSpcBody(string tag, string attr, vector<string> *ftr){
        string mTag = "<" + tag;
        stringParse *strPrs = new stringParse(cStr);
        vector <long long int> t = strPrs -> doKmp(mTag);
        string tAttr, tValue;



        int pos=0, c = attr.length();

        for(int i=0; i<c; i++)
        {
            if(attr[i]=='='){
                pos=i+1;
                break;
            }
            else tAttr+=attr[i];
        }
        for(int i=pos; i<c; i++) tValue +=attr[i];

        long long int prpTag;
        for(int i=0; i<t.size();i++){
            prpTag = t[i];
            string tagStr = getTagAll(prpTag,tag);
            string fValue = attrSearch(tAttr,&tagStr);
            long long int flag = strPrs -> doKmpAttr(&tValue,&fValue);
            if(flag!=-1){
                ftr->push_back(getTagBody(prpTag, tag));
            }

        }





    }


    virtual ~stringParse(){
        //destructor
        //cout<<"dest string ";
    }
};
#endif // STRINGPARSE_H_INCLUDED

